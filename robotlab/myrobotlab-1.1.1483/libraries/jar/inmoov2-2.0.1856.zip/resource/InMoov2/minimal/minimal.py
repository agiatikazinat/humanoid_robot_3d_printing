def disableAll():
  i01.disable()
def detachAll():
  disableAll()