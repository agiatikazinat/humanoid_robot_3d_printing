#########################################
# i01_leapMotion_stop.py
# categories: inmoov2
# more info @: http://myrobotlab.org/service/InMoov
#########################################
# uncomment for virtual hardware

# release random timers
i01_leap.stopTracking()
#runtime.release("i01.leap")