#########################################
# i01_rightHandSensors_Value.py
# categories: inmoov2
# more info @: http://myrobotlab.org/service/InMoov
#########################################
rightHandSensorON()
sleep(1)
rightHandSensorOFF()