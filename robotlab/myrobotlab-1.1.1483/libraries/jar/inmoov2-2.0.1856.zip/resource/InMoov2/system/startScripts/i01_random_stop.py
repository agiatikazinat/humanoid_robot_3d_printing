#########################################
# i01_random_start.py
# categories: inmoov2
# more info @: http://myrobotlab.org/service/InMoov
#########################################
# uncomment for virtual hardware

# release random timers
runtime.release("moveHeadRandomize")
runtime.release("moveBodyRandomize")
