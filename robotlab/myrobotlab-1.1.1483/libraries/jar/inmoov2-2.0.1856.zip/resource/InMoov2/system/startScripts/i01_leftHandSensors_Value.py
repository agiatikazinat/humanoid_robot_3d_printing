#########################################
# i01_leftHandSensors_Value.py
# categories: inmoov2
# more info @: http://myrobotlab.org/service/InMoov
#########################################
leftHandSensorON()
sleep(1)
leftHandSensorOFF()