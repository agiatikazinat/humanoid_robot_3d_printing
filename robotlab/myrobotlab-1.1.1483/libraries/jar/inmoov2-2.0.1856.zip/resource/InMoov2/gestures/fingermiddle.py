def fingermiddle():
  i01_rightHand_index.setSpeed(500)## Maximum speed
  i01_rightHand_index.moveTo(90)
  i01.finishedGesture()