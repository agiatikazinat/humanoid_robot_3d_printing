def eyesleft():
  #i01.startedGesture()
  i01_head_eyeX.moveTo(180)
  sleep(1)
  i01.finishedGesture()

