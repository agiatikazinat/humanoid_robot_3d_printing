def startcopygestures():
  startkinect()
  i01.fullSpeed()
  #i01.copyGesture(True)
  i01_openni.capture()
