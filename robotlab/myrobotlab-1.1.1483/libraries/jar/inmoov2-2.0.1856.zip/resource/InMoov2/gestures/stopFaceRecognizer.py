def stopfacerecognizer():
  #i01_opencv.stopCapture()
  i01_opencv.removeFilter("PyramidDown")
  i01_opencv.removeFilter("FaceRecognizer")
