def victory():
  #i01.startedGesture()
  i01.moveHead(114,90)
  i01.moveArm("left",90,91,106,10)
  i01.moveArm("right",0,73,30,17)
  i01.moveHand("left",170,0,0,168,167,0)
  i01.moveHand("right",98,37,34,67,118,166)
  i01.moveTorso(90,90,90)
  i01.finishedGesture()
