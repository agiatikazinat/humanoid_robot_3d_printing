def headfront():
  i01_head_neck.moveTo(90)
  i01_head_rothead.moveTo(90)
  i01.finishedGesture()

