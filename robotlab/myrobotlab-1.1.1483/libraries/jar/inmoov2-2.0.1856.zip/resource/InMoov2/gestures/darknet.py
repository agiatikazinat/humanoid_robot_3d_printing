def darknet():
  ImageYolo.closeAll()
  takeFotoForYolo()
  statisticResult()
  sleep(0.1)
  analyseResult()
  #displayPic("c:\myrobotlab\yolo\predictions.jpg")
  i01.finishedGesture()
