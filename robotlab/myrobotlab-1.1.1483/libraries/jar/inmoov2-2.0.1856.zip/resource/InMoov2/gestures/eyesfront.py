def eyesfront():
  #i01.startedGesture()
  i01_head_eyeX.moveTo(90)
  i01_head_eyeY.moveTo(90)
  i01.finishedGesture()

