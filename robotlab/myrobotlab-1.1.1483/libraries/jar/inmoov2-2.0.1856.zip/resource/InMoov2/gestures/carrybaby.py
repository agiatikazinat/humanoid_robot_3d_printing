def carrybaby():
  #i01.startedGesture()
  i01.moveHead(18,111,85,85,5)
  i01.moveArm("left",81,50,45,16)
  i01.moveArm("right",78,44,50,31)
  i01.moveHand("left",180,180,180,180,180,25)
  i01.moveHand("right",111,128,140,151,169,86)
  i01.moveTorso(90,90,90)
  i01.finishedGesture()


