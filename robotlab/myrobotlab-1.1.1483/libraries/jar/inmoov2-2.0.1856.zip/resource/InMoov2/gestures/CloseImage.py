def CloseImage():
  i01_imageDisplay.exitFS()
  sleep(1)
  i01_imageDisplay.closeAll()
  i01.finishedGesture()
