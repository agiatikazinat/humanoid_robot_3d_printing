def headleft():
  i01.head.rothead.moveTo(180)
  i01.finishedGesture()

