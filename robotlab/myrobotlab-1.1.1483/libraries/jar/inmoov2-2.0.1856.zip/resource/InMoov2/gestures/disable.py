def disable():
  i01.disable()
  i01.finishedGesture()
