def guesswhat():
  i01_mouth.speak("I'm not really a human man")
  #i01_mouth.speak(u"Я на самом деле не человек")
  i01_mouth.speak("but I use Old spice body wash and deodorant together")
  # i01_mouth.speak(u"Но я использую Old spice и дезодорант для тела")
  i01_mouth.speak("and now I'm really cool")
  #i01_mouth.speak(u"И теперь я действительно крутой")
  i01.finishedGesture()
  


