def openlefthand():
  i01.moveHand("left",0,0,0,0,0)
  i01.finishedGesture()


