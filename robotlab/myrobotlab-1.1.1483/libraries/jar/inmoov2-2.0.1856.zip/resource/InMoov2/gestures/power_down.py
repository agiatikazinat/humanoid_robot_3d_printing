def power_down():
  sleepModeSleep()