def eyesright():
  #i01.startedGesture()
  i01_head_eyeX.moveTo(0)
  sleep(1)
  i01.finishedGesture()

