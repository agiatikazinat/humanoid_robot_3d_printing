def eyesup():
  #i01.startedGesture()
  i01_head_eyeY.moveTo(0)
  sleep(1)
  i01.finishedGesture()

