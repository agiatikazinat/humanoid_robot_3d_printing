def headright():
  i01_head_rothead.moveTo(0)
  i01.finishedGesture()

