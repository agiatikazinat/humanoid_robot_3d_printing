def eyesdown():
  #i01.startedGesture()
  i01_head_eyeY.moveTo(180)
  sleep(1)
  i01.finishedGesture()

