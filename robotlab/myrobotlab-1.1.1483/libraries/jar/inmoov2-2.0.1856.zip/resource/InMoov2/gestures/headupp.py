def headupp():
  i01_head_neck.moveTo(180)
  i01.finishedGesture()

