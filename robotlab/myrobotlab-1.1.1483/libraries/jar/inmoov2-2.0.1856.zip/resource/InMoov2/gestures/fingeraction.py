def fingeraction():
   #i01.startedGesture()
   i01_rightHand_index.setSpeed(500)## High speed
   i01_rightHand_index.moveTo(0)
   i01_rightHand_index.moveTo(180)
   i01_rightHand_index.moveTo(0)
   i01_rightHand_index.moveTo(180)
   i01_rightHand_index.moveTo(0)
   i01_rightHand_index.moveTo(180)
   i01_rightHand_index.moveTo(0)
   i01.finishedGesture()