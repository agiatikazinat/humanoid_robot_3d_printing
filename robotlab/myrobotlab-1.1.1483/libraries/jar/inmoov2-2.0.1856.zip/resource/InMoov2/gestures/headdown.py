def headdown():
  i01_head_neck.moveTo(0)
  i01.finishedGesture()

