def fingerclose():
  i01_rightHand_index.setSpeed(100)## Medium speed
  i01_rightHand_index.moveTo(180)
  i01.finishedGesture()