def fingeropen():
  i01_rightHand_index.setSpeed(20)## Low speed
  i01_rightHand_index.moveTo(0)## Thumb,index,majeure,ringfinger,pinky,wrist
  i01.finishedGesture()