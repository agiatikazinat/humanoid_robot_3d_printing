def power_up():
  sleepModeWakeUp()